package com.katjmerikurdi.app;

import android.app.*;
import android.os.*;
import android.graphics.Color;
import android.view.*;
import android.widget.*;
import java.text.SimpleDateFormat;
import java.util.*;

public class MainActivity extends Activity {
    LinearLayout root, body, nav;
    Handler handler = new Handler();
    long swStart=0, swAccum=0, timerEnd=0;
    boolean swRunning=false, timerRunning=false;
    TextView clockText, dateText, status;
    Runnable ticker = new Runnable(){ public void run(){ updateClock(); handler.postDelayed(this,1000); }};
    int cyan=Color.rgb(40,215,229), white=Color.WHITE, muted=Color.rgb(160,178,195);
    public void onCreate(Bundle b){ super.onCreate(b); showHome(); handler.post(ticker); }
    int dp(float v){return (int)(v*getResources().getDisplayMetrics().density);}
    TextView text(String s,int size,int color){ TextView t=new TextView(this); t.setText(s); t.setTextSize(size); t.setTextColor(color); t.setGravity(Gravity.CENTER); t.setPadding(dp(8),dp(8),dp(8),dp(8)); return t; }
    LinearLayout column(){ LinearLayout l=new LinearLayout(this); l.setOrientation(1); l.setPadding(dp(18),dp(14),dp(18),dp(12)); return l; }
    Button button(String s){ Button b=new Button(this); b.setText(s); b.setTextColor(white); b.setAllCaps(false); b.setBackgroundTintList(android.content.res.ColorStateList.valueOf(Color.rgb(22,43,58))); return b; }
    void base(String title){
        root=column(); root.setBackgroundColor(Color.rgb(5,10,18)); setContentView(root);
        TextView h=text("◉  "+title,24,cyan); root.addView(h,new LinearLayout.LayoutParams(-1,dp(65)));
        body=column(); root.addView(body,new LinearLayout.LayoutParams(-1,0,1));
        nav=new LinearLayout(this); nav.setOrientation(0);
        String[] names={"سەرەکی","ئاڵارم","تایمەر","کرۆنۆمەتەر","کاتی جیهان"};
        for(int i=0;i<names.length;i++){ final int n=i; Button b=button(names[i]); b.setTextSize(10); nav.addView(b,new LinearLayout.LayoutParams(0,dp(58),1)); b.setOnClickListener(v->page(n)); }
        root.addView(nav);
    }
    void page(int n){ if(n==0)showHome(); if(n==1)showAlarm(); if(n==2)showTimer(); if(n==3)showStopwatch(); if(n==4)showWorld(); }
    void updateClock(){
        if(clockText!=null) clockText.setText(new SimpleDateFormat("HH:mm:ss",Locale.getDefault()).format(new Date()));
        if(dateText!=null) dateText.setText(new SimpleDateFormat("EEEE، d MMMM yyyy",new Locale("ckb")).format(new Date()));
        if(status!=null && timerRunning){ long left=Math.max(0,timerEnd-System.currentTimeMillis()); status.setText(String.format(Locale.getDefault(),"%02d:%02d",left/60000,(left/1000)%60)); if(left==0){timerRunning=false; status.setText("کات تەواو بوو!");}}
    }
    void showHome(){
        base("کاتژمێری کوردی"); clockText=text("00:00:00",54,white); body.addView(clockText);
        dateText=text("",18,muted); body.addView(dateText);
        TextView info=text("بەخێربێیت بۆ کاتژمێری کوردی",18,cyan); body.addView(info);
        TextView details=text("ئاڵارم  •  تایمەر  •  کرۆنۆمەتەر  •  کاتی شارەکانی جیهان",14,muted); body.addView(details);
        updateClock();
    }
    void showAlarm(){
        base("ئاڵارم"); body.addView(text("کاتی ئاگادارکردنەوە دیاری بکە",18,white));
        TimePicker picker=new TimePicker(this); picker.setIs24HourView(true); body.addView(picker);
        Button save=button("دانانی ئاڵارم"); body.addView(save);
        TextView msg=text("",16,cyan); body.addView(msg);
        save.setOnClickListener(v->{ int h=picker.getHour(),m=picker.getMinute(); Calendar c=Calendar.getInstance(); c.set(Calendar.HOUR_OF_DAY,h); c.set(Calendar.MINUTE,m); c.set(Calendar.SECOND,0); if(c.getTimeInMillis()<=System.currentTimeMillis())c.add(Calendar.DAY_OF_YEAR,1);
            long delay=c.getTimeInMillis()-System.currentTimeMillis();
            new Handler().postDelayed(()->{ try { ((android.media.AudioManager)getSystemService(AUDIO_SERVICE)).adjustStreamVolume(android.media.AudioManager.STREAM_ALARM,android.media.AudioManager.ADJUST_RAISE,0); }catch(Exception e){} new AlertDialog.Builder(this).setTitle("ئاڵارم").setMessage("کاتی دیاریکراو گەیشت!").setPositiveButton("باشە",null).show(); },delay);
            msg.setText(String.format(Locale.getDefault(),"ئاڵارم بۆ %02d:%02d دانرا (تا کاتی بەکارهێنانی ئەپ)",h,m));
        });
    }
    void showTimer(){
        base("تایمەر"); EditText mins=new EditText(this); mins.setHint("ژمارەی خولەک"); mins.setInputType(2); mins.setTextColor(white); body.addView(mins);
        status=text("00:00",48,cyan); body.addView(status);
        Button start=button("دەستپێکردن"); body.addView(start);
        Button stop=button("وەستاندن"); body.addView(stop);
        start.setOnClickListener(v->{int m=0;try{m=Integer.parseInt(mins.getText().toString());}catch(Exception e){} if(m<1){status.setText("تکایە خولەک بنووسە");return;} timerEnd=System.currentTimeMillis()+m*60000L;timerRunning=true;});
        stop.setOnClickListener(v->{timerRunning=false;status.setText("وەستاوە");});
    }
    void showStopwatch(){
        base("کرۆنۆمەتەر"); status=text("00:00.0",48,cyan); body.addView(status);
        Button toggle=button("دەستپێکردن / وەستاندن"); body.addView(toggle);
        Button reset=button("ڕیسێت"); body.addView(reset);
        Runnable r=new Runnable(){public void run(){if(swRunning){long x=swAccum+System.currentTimeMillis()-swStart;status.setText(String.format(Locale.getDefault(),"%02d:%02d.%d",x/60000,(x/1000)%60,(x/100)%10));handler.postDelayed(this,100);}}};
        toggle.setOnClickListener(v->{if(swRunning){swAccum+=System.currentTimeMillis()-swStart;swRunning=false;}else{swStart=System.currentTimeMillis();swRunning=true;handler.post(r);}});
        reset.setOnClickListener(v->{swRunning=false;swAccum=0;status.setText("00:00.0");});
    }
    void showWorld(){
        base("کاتی شارەکانی جیهان");
        String[][] cities={{"هەولێر","Asia/Baghdad"},{"سلێمانی","Asia/Baghdad"},{"مەککە","Asia/Riyadh"},{"دوبەی","Asia/Dubai"},{"لۆندەن","Europe/London"},{"نیویۆرک","America/New_York"},{"تۆکیۆ","Asia/Tokyo"}};
        for(String[] c:cities){try{TextView t=text(c[0]+"   "+new SimpleDateFormat("HH:mm",Locale.getDefault()).format(Calendar.getInstance(TimeZone.getTimeZone(c[1])).getTime()),22,white);body.addView(t);}catch(Exception e){}}
        body.addView(text("کاتەکان بە پێی ناوچەی کاتی هەر شارێک پیشان دەدرێن.",13,muted));
    }
}
